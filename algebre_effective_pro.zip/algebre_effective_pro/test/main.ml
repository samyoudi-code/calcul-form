open R_gauss

let () = 
 let x = of_string "1+3/2i" in 
match x with 
|Some v -> print_endline (to_string v)
|None -> print_endline "Erreur de convertion"

let q = 
 let x = of_string "1+3/2i" in 
match x with 
Some v -> v
|None -> zero

let () = print_endline (to_string (q + one))
let () =  print_endline (to_string q)
let () =  print_endline "OK r_gauss fonctionne"
