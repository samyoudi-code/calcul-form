type t = (int * Q.t) list

let zero = [];;

let one = [(0, Q.one)]
let minus_one =  [(0, Q.minus_one)]

let is_polynomial p = 
let rec aux pre p =
match p with 
[] -> true
|(d,c)::q -> Q.equal c Q.zero && d >= 0 && d > pre && aux d q 
in aux (-1) p;; 

let rec equ (p:t) (q:t) = match p,q with 
[],[] -> true 
| [],_|_,[] -> false
|m::r, m'::r' -> fst m = fst m' && Q.equal (snd m) (snd m') && equ r r'

let rec purge (p:t):t = 
match p with 
[] -> []
| m::q -> if (fst m) <> 0 then m::purge q else purge q 

let rec coeff (p:t) d = 
match p with 
[] -> Q.zero
|m::_ when (fst m) = d -> snd m
|_::q-> coeff q d

let degree p = 
if equ p zero then -1
else let q = List.rev p in 
fst (List.hd q)
          
let cd (p:t) = 
match List.rev p with 
[] -> Q.zero
|m::_ -> snd m

let rec add p q = match p,q with 
|([], t) | (t, []) -> t
|(d,c)::t,(d', c')::t' when d = d'-> if Q.equal c (Q.mul Q.minus_one c') then add t t' 
                                      else (d, Q.add c c')::add t t'

|((d, c):: t, (d', c')::t') when d > d' -> (d, c) :: (add t ((d',c')::t'))
|(t, (d', c')::t') -> (d', c') :: (add t t')

let multCoeff c p = 
let rec aux acc = function
[]-> List.rev acc
|(d,c')::t-> aux ((d, Q.mul c c')::acc) t
in aux [] p

let sub p q = add p (multCoeff (Q.minus_one) q)

let to_string (p : t) : string =
  let rec aux acc =
    function
    | [] -> acc
    | (n, c) :: p when n = 0 -> aux (Q.to_string c) p
    | (n, c) :: p when n = 1 && Q.(c = Q.one) && acc = "" -> aux "X" p
    | (n, c) :: p when n = 1 && Q.(c = Q.one) -> aux "+X" p
    | (n, c) :: p when n = 1 && Q.(c = Q.minus_one) -> aux (acc ^ "-X") p
    | (n, c) :: p when n = 1 && Q.(c < Q.zero)
      -> aux (acc ^ (Q.to_string c) ^ "X") p
    | (n, c) :: p when n = 1 && acc = "" -> aux ((Q.to_string c) ^ "X") p
    | (n, c) :: p when n = 1 -> aux (acc ^ "+" ^ (Q.to_string c) ^ "X") p
    | (n, c) :: p when Q.(c = Q.one) && acc = ""
      -> aux ("X^" ^ (string_of_int n)) p
    | (n, c) :: p when Q.(c = Q.one)
      -> aux (acc ^ "+X^" ^ (string_of_int n)) p
    | (n, c) :: p when Q.(c = Q.minus_one)
      -> aux (acc ^ "-X^" ^ (string_of_int n)) p
    | (n, c) :: p when Q.(c < Q.zero)
      -> aux (acc ^ (Q.to_string c) ^ "X^" ^ (string_of_int n)) p
    | (n, c) :: p
      -> aux (acc ^ "+" ^ (Q.to_string c) ^ "X^" ^ (string_of_int n)) p
  in (if p = []
      then "0"
      else aux "" p)


let of_string (s : string) : t option =
  let long = String.length s
  in (if long = 0
      then Some []
      else
        (let is_digit c = c >= '0' && c <= '9'
         and is_as c = c = '+' || c = '-'
         and is_sl c = c = '/'
         and is_X c = c = 'X'
         and is_pow c = c = '^'
         in (let rec aux p coef exp n i =
               if i = long
               then
                 (match n with
                 | 0 -> Some p
                 | 1 -> Some (add p [0, Q.of_string coef])
                 | 2 | 3 | 6 -> None
                 | 4 -> Some (add p [0,  Q.of_string coef])
                 | 5 -> Some (add p [1,  Q.of_string coef])
                 | 7 -> Some (add p [int_of_string exp,  Q.of_string coef])
                 | _ -> None)
               else
                 match (n,s.[i]) with
                 | 0, c when is_digit c -> aux p (coef ^ (Char.escaped c)) exp
                                             1 (i + 1)
                 | 0, c when is_as c -> aux p (Char.escaped c) exp 2 (i + 1)
                 | 0, c when is_X c -> aux p "1" exp 5 (i + 1)
                 | 1, c when is_digit c -> aux p (coef ^ (Char.escaped c)) exp
                                             1 (i + 1)
                 | 1, c when is_sl c -> aux p (coef ^ (Char.escaped c)) exp 3
                                          (i + 1)
                 | 1, c when is_as c -> aux (add p [0, Q.of_string coef])
                                          (Char.escaped c) exp 2 (i + 1)
                 | 1, c when is_X c -> aux p coef exp 5 (i + 1)
                 | 2, c when is_digit c -> aux p (coef ^ (Char.escaped c)) exp
                                             1 (i + 1)
                 | 2, c when is_X c -> aux p (coef ^ "1") exp 5 (i + 1)
                 | 3, c when is_digit c -> aux p (coef ^ (Char.escaped c)) exp
                                             4 (i + 1)
                 | 4, c when is_digit c -> aux p (coef ^ (Char.escaped c)) exp
                                             4 (i + 1)
                 | 4, c when is_as c -> aux (add p [0, Q.of_string coef])
                                          (Char.escaped c) exp 2 (i + 1)
                 | 4, c when is_X c -> aux p coef exp 5 (i + 1)
                 | 5, c when is_pow c -> aux p coef exp 6 (i + 1)
                 | 5, c when is_as c -> aux (add p [1, Q.of_string coef])
                                          (Char.escaped c) "" 2 (i + 1)
                 | 6, c when is_digit c -> aux p coef (exp ^ (Char.escaped c))
                                             7 (i + 1)
                 | 7, c when is_digit c -> aux p coef (exp ^ (Char.escaped c))
                                             7 (i + 1)
                 | 7, c when is_as c -> aux (add p [int_of_string exp,
                                                    Q.of_string coef])
                                          (Char.escaped c) "" 2 (i + 1)
                 | _ -> None
             in aux zero "" "" 0 0)))      

let rec mult_monome d p = match p with  
[] -> []
|(a,c)::q -> if d = 0 then p else (a+d, c)::mult_monome d q

let rec mult_naive p q = match p with 
[]-> []
|(a,b)::t -> add (mult_monome a (multCoeff b q)) (mult_naive t q)

let rec casse p d = match p with 
[]-> [],[]
|(a,b)::t -> let p1,p2 = casse t d in if a < d then (a,b)::p1,p2 else p1,(a-d,b)::p2


let choisir_coupure d1 d2 = let d = if d1 > d2 then d1 else d2 in if d mod 2 = 0 then d / 2 else (d + 1) / 2

let rec mult p q s = match p,q with 
[],_ | _,[] -> []
|(a,_)::_,(a',_)::_ -> if a < s && a' < s then mult_naive p q else 
  let k = choisir_coupure a a' in
  let p0,p1 = casse p k in
  let q0,q1 = casse q k in
  let a0 = mult p0 q0 k in
  let a2 = mult p1 q1 k in
  let u = mult (add p0 p1) (add q0 q1) k in
  let a1 = sub (sub u a0) a2 in
  add (add a0 (mult_monome (k/2) a1)) (mult_monome k a2)  

  let rec renverse n (p : t) =
  if n < degree p then None
  else
    match p with
    | [] -> Some []
    | (a,b)::t ->
        match renverse n t with
        | None -> None
        | Some q -> Some (List.rev ((n - a, b) :: q))

let modulo p n = 
  let rec aux acc p = match p with 
   [] -> List.rev acc
  |(a,b)::t -> if a < n then aux ((a,b)::acc) t else aux acc t in aux [] p

let inverse_mod p m = 
  match p with
  |(a,b)::_ when not(Q.equal b Q.one) || a <> 0 -> failwith "erreur"
  |[] -> failwith "division par 0"
  | _ -> 
    let rec aux p' = function 
    |i when i >= m -> modulo p' m   
    |i -> 
      let k = min (2 * i) m in 
      let p'' = modulo (add p' (mult p' (sub one (modulo (mult p' p 1) k)) 1)) k in
        aux p'' (2 * i)
    in
      aux one 0

  
let quotient p1 p2 = match  p1, p2 with 
  [], _ -> []
 |_,[]-> failwith "Erreur division par 0"
 |p1, p2 -> 
    let b =  cd p2 in 
    let n = degree p1 in 
    let m = degree p2 in
    match (renverse m p2) with 
    |None -> failwith "erreur"
    |Some v -> 
          let p = multCoeff (Q.inv b) v in 
          let g  = inverse_mod p (n-m+1) in 
          match (renverse n p1) with 
          |None -> failwith "erreur"
          |Some v' -> 
            let q' = (mult v' (multCoeff b (modulo g (n-m+1))) 1) in 
            match renverse (n-m) q' with 
            |None -> failwith "erreur"
            |Some q -> q

let reste p1 p2 = 
  let q = quotient p1 p2 in 
  sub p1 (mult q p2 1)


let eval p e = match p with 
[] -> Q.zero 
|p -> let p' = List.tl (List.rev p) in 
let rec aux acc p = match p with 
[] -> acc 
|(_, a)::q -> aux (Q.add (Q.mul acc e) a) q in 
    aux (cd p) p'


type point = {x:Q.t; y:Q.t}

let calcule_point p x = { x = x; y = eval p x}

type ab = Vide | Noeud of t * ab * ab


let rec split i lst =
        match lst with
        | [] -> [], []
        | x::xs ->
            let a0, a1 = split (i-1) xs in
            if i > 0 then x::a0, a1 else a0, x::a1 
  
let rec ab_sp l = match l with
[] -> Vide 
|[e] -> Noeud([(1, Q.one); (0, (Q.mul Q.minus_one e))], Vide,Vide)
|_ -> 
  let n = List.length l in 
  let c = n / 2 in 
  let p0,p1 = split c l in 
  let a0 = ab_sp p0 in
  let a1 = ab_sp p1 in 
  let q0 = match a0 with 
  |Vide -> [(0, Q.one)]
  |Noeud(p,_,_) -> p in 
  let q1 = match a1 with 
   |Vide -> [(0, Q.one)]
  |Noeud(p,_,_) -> p in
  let r = mult q0 q1 10 in 
  Noeud(r,a0, a1) 

let ab_r r lv =
  let a = ab_sp lv in
  let rec aux r' a' =
    match a' with
    | Vide -> Vide
    | Noeud(p,a0,a1) ->
        let r0 = reste r' p in
        let b0 = aux r0 a0 in
        let b1 = aux r0 a1 in
        Noeud(r0,b0,b1)
  in
  aux r a


let rec eval_map p abs =
  match abs with
  | [] -> []
  | t::q -> (t, eval p t) :: eval_map p q


let eval_m p abs =  
  if List.length abs < degree p then eval_map p abs 
    else 
     let a = ab_r p abs in 
    let rec aux a' l =
      match a', l with
      | Vide, _ -> []
      | Noeud(r, Vide, Vide), t::q -> (t, cd r) :: aux Vide q
      | Noeud(_, g, d), _ ->
          let n = List.length l / 2 in
          let a0, a1 = split n l in
          aux g a0 @ aux d a1
    in
    aux a abs


let derivee p = 
  let rec aux acc = function 
  [] -> List.rev acc
  |(d,c)::q when d = 0 -> aux acc q
  |(d,c)::q -> aux ((d - 1, Q.mul (Q.of_int d) c)::acc) q in 
  aux [] p


let rec mul_abs abs =
  match abs with
  | [] -> [(0, Q.one)]
  | t :: q ->
      let p = [(1, Q.one); (0, Q.mul Q.minus_one t.x)] in
      let r = mul_abs q in
      mult p r 10


let interpolation_naive abs = 
  let p = mul_abs abs in
  let rec aux acc abs =
    match abs with
    | [] -> List.rev acc
    | t :: q ->
      let pi = div p [(1, Q.one); (0, Q.mul Q.minus_one t.x)] in
      let ei = eval pi t.x in
      aux (add acc (multCoeff (Q.mul t.y (Q.inv ei)) pi) ) q
    in aux zero abs
  

 
(**************PROJET**************)

(********INTERPOLATION DE NEWTON********)
(*representation de X + 1*)
let monomX1 = [(0, Q.one); (1, Q.one)]


(*calcule P^n*)
let pow_poly p n = 
  if n = 0 then one               (* p^0 = 1 *)
  else 
    mult p (pow_poly p (n-1)) 10


(*calcule P(X + 1)*)
let eval_enX1 p = List.fold_left
    (fun acc (d, c) ->
       add acc (multCoeff c (pow_poly monomX1 d)))
    zero
    p

(*calcule P(X + 1) - P(X) aka delta P *)

let delta p = sub (eval_enX1 p) p

let delta_n p n = 
  if n = 0 then p
  else delta (delta_n p (n-1))

(*QST2*)
let rec diff_liste l = match l with 
[]|[_] -> []
|x::y::q -> (Q.sub y x)::diff_liste (y::q)


let rec suivant_suite l = match l with 
[] -> failwith "erreur"
|[x] -> x
|_ -> let d = diff_liste l in Q.add (suivant_suite d) (List.nth l (List.length l - 1))

(*QST3*)

let pol_newton_acc n = 
  if n = 0 then one else
  let rec aux acc i = match i with
  n when i = n -> acc
  |k -> let x = if k = 1 then [(0, Q.one)] else [(0, Q.of_int (1-k)); (1, Q.one)]
  in let acc' = multCoeff (Q.inv (Q.of_int k)) (mult acc x 10) in aux acc' (i+1)
in aux one 1
  

let pol_newton n = 
  let rec aux i = 
    if i >= n then []
    else pol_newton_acc i :: aux (i+1)
  in aux 0


let interpol_newton l =
  let newtons = pol_newton (List.length l) in
  let rec aux l newtons =
    match l, newtons with
    | [], _ | _, [] -> zero
    | a0 :: _, nk :: r ->
        let x = multCoeff a0 nk in
        add x (aux (diff_liste l) r)
  in
  aux l newtons

(***********Développement de Taylor des fractions rationnelles*****************)

(*********M1*******)

type frac_rat = {num:t; den:t}

 let derivee_frac_rat f = 
  let num' = derivee f.num in
  let den' = derivee f.den in
  let num'' = sub (mult num' f.den 10) (mult f.num den' 10) in
  let den'' = pow_poly f.den 2 in
  {num = num''; den = den''}

let test_frac_rat f = let h,t = List.hd f.den, List.tl f.den
in is_polynomial f.num && equ [h] one && Q.equal (eval t Q.zero) Q.zero

let eval_0 f = eval f.num Q.zero

let dev1 n f = 
  if not (test_frac_rat f) then failwith "fraction pas sous la bonne forme" else 
  let rec aux f_cur i fact acc = match i with
  n -> List.rev acc
  |k -> (* F^(i)(0) / i! comme coefficient de X^i *)
    let ci = Q.div (eval_0 f_cur) fact
     let x = if Q.equal ci Q.zero then zero
                  else [(i, ci)] in
    let f' = derivee_frac_rat f_cur in
    aux f' (i+1) (Q.mul fact (Q.of_int (i+1))) (add acc x)
in aux f 0 Q.one zero
    
(*********M2*******)

let dev_aux1 n f = 
  if not (test_frac_rat f) then failwith "fraction pas sous la bonne forme"
  else 
    inverse_mod f.den (n + 1)

let dev2 n f =
if not (test_frac_rat f) then failwith "fraction pas sous la bonne forme"
else 
    let f1 = { num = one; den = f.den } in
    let inv = dev_aux1 n f1 in
    modulo (mult f.num inv 10) (n + 1)

(*********M3*******)

let compose p q =   List.fold_left
    (fun (d, c) acc ->
       add (multCoeff c (pow_poly q d)) acc)
    p zero

(* H = 1 + X + X^2 + ... + X^n  (developpement de 1/(1-X) a l'ordre n) *)
let h n =
  let rec aux acc k =
    if k > n then List.rev acc
    else aux ((k, Q.one) :: acc) (k + 1)
  in aux [] 0


let dev_aux2 n f = 
    if not (test_frac_rat f) then failwith "fraction pas sous la bonne forme"
  else
        let q = sub f.den one 
     in
    modulo (compose (h n) (multCoeff Q.minus_one q)) (n + 1)

let dev3 n f =
  if not (test_frac_rat f) then failwith "fraction pas sous la bonne forme"
  else
    let f1 = { num = one; den = f.den } in
    let inv = dev_aux2 n f1 in
    modulo (mult f.num inv 10) (n + 1)

