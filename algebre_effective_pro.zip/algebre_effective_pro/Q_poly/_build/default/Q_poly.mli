(**
   Ensemble des polynômes à coefficients rationnels

   Cette interface fixe les opérations nécessaires pour une structure 
   algébrique effective correspondant à l'ensemble des polynômes à coefficients 
   rationnels. 

   L'implantation fait appel au module Q des nombres rationnels de la 
   bibliothèque zarith. 

   Les polynômes sont implantés en représentation creuse. 

*)

(** {1 Types} *)

type t = (int * Q.t) list
(** Type pour les polynômes à coefficients rationnels. Le premier élément du 
    couple est le degré. Le second élément est le coefficient de type Q.t. Les 
    degrés sont positifs et classés en ordre croissant dans la liste. Les 
    coefficients sont non nuls. *)

val is_polynomial : t -> bool
(** Teste si la liste de couples est un polynôme. *)

val purge : t -> t
(** Supprime d'éventuels coefficients nuls. *)

val coeff : int -> t -> Q.t
(** Calcule le coefficient d'un certain degré pour un polynôme. *)

val degree : t -> int
(** Calcule le degré d'un polynôme. *)

val cd : t -> Q.t
(** Calcule le coefficient dominant du polynôme. *)

(** {1 Construction} *)

val zero : t
(** L'élément neutre pour l'addition. *)

val one : t
(** L'élément neutre pour la multipication. *)

val minus_one : t
(** L'élément opposé à l'élément neutre pour la multiplication. *)

(** {1 Principales opérations arithmétiques} *)

val mult_coeff : Q.t -> t -> t
(** Multiplie un polynôme par un coefficient. *)

val opp : t -> t
(** Opposé d'un élément. *)

val add : t -> t -> t
(** Addition. *)

val sub : t -> t -> t
(** Soustraction. *)

(** {1 Conversion} *)

val to_string : t -> string
(** Convertit un élément en une chaîne de caractères. *)

val of_string : string -> t option
(** Convertit une chaîne de caractères en un élément. *)

(** {1 Égalité} *)

val equ : t -> t -> bool
(** Teste l'égalité de deux éléments. *)

(** {1 Opérateurs préfixes et infixes} *)

val ( ~- ) : t -> t
(** Opposé d'un élément [opp]. *)

val ( ~+ ) : t -> t
(** Identité. *)

val ( + ) : t -> t -> t
(** Addition [add]. *)

val ( - ) : t -> t -> t
(** Subtraction [sub]. *)

val ( = ) : t -> t -> bool
(** Identique à equ. *)
